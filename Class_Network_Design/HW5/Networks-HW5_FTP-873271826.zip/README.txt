the ftp files in the main directory are the versions from combining all the stuff from the backups. 
The "test_run" folder had download and send working near perfect. 
Ignore 'examples', those are the given templates. 

- Nathan Cauwet